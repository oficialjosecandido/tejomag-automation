#!/bin/bash
# Azure App Service startup script

echo "Starting TejoMag Backend..."

# Create logs directory
mkdir -p logs

# Start Gunicorn with proper configuration
gunicorn --bind=0.0.0.0:8000 \
         --workers=2 \
         --threads=4 \
         --timeout=300 \
         --access-logfile=- \
         --error-logfile=- \
         --log-level info \
         --preload \
         app:app

